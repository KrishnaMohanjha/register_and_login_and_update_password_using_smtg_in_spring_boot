package com.project.smtp.util;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;

@Component
public class JwtTokenProvider {

    private Key secretKey;
    private long validityInMilliseconds = 3600000; // 1 hour

    @PostConstruct
    protected void init() {
        this.secretKey = Keys.secretKeyFor(SignatureAlgorithm.HS256); // Generate a secure key
    }

    public String createToken(String email) {
        return Jwts.builder()
                .setSubject(email)
                //.claim("name", name)
                //.claim("mobile", mobile)
                .setIssuedAt(new Date())
                .setExpiration(new Date(new Date().getTime() + validityInMilliseconds))
                .signWith(secretKey)
                .compact();
    }
    public String getEmailFromToken(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(secretKey)
                .build()
                .parseClaimsJws(token.replace("Bearer ", ""))
                .getBody();
        return claims.getSubject(); 
    }
}