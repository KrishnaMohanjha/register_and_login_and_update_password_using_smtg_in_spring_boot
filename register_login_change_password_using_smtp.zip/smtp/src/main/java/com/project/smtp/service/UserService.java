package com.project.smtp.service;

import java.security.SecureRandom;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.project.smtp.entity.User;
import com.project.smtp.repository.UserRepository;
import com.project.smtp.util.JwtTokenProvider;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private EmailService emailService;

    private SecureRandom random = new SecureRandom();

    private String generateRandomPassword() {
        byte[] randomBytes = new byte[8];
        random.nextBytes(randomBytes);
        return Base64.getEncoder().encodeToString(randomBytes);
    }

    public String registerUser(User user) {
        String email = user.getEmail();
        if (userRepository.findByEmail(email) != null) {
            return "User already exists";
        }

        String randomPassword = generateRandomPassword();
        String encodedPassword = passwordEncoder.encode(randomPassword);
        user.setPassword(encodedPassword);

        userRepository.save(user);

        emailService.sendEmail(email, "Registration Successful", "Your registration is successful. Your password is: " + randomPassword);
        return "Registration successful";
    }

    public String loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return jwtTokenProvider.createToken(email);
        } else {
            return "Invalid credentials";
        }
    }

    public boolean updatePassword(String email, String oldPassword, String newPassword) {
        User user = userRepository.findByEmail(email);
        if (user != null && passwordEncoder.matches(oldPassword, user.getPassword())) {
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            return true;
        } else {
            return false;
        }
    }

    public boolean getLogin(String email, String password) {
        User user = userRepository.findByEmail(email);
        return user != null && passwordEncoder.matches(password, user.getPassword());
    }
}
